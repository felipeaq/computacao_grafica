import sys
import random

for i in sys.stdin:
    print("{} {} {}".format(random.random(),random.random(),random.random()))
